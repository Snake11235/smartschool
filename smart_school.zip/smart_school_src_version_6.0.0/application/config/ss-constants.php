<?php

defined('BASEPATH') OR exit('No direct script access allowed');

define('INSERT_RECORD_CONSTANT', 'New Record inserted');
define('UPDATE_RECORD_CONSTANT', 'Record updated');
define('DELETE_RECORD_CONSTANT', 'Record deleted');

